package com.bignerdranch.android.pr20_komarov.database

import androidx.room.Dao
import androidx.room.Query
import com.bignerdranch.android.pr20_komarov.Crime
import java.util.*

@Dao
interface CrimeDao {
    @Query("SELECT * FROM crime")
    fun getCrimes(): List<Crime>
    @Query("SELECT * FROM crime WHERE id=(:id)")
    fun getCrime(id: UUID): Crime?
}